package practice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Bootstrapdropdown {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");

  WebDriver driver=new ChromeDriver();
  driver.get("https://www.amazon.in/?&ext_vrnc=hi&tag=googinhydr1-21&ref=pd_sl_98xjxt98l7_b&adgrpid=60639568242&hvpone=&hvptwo=&hvadid=617721280315&hvpos=&hvnetw=g&hvrand=487348762000321118&hvqmt=b&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1007788&hvtargid=kwd-299123108802&hydadcr=5841_2362028&gclid=EAIaIQobChMI8Y_4u6uf_AIVEx4rCh1M4wPBEAAYASAAEgK4evD_BwE");
  driver.findElement(By.xpath("//*[@id=\"nav-hamburger-menu\"]")).click();
  driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/ul[1]/li[15]/a")).click();

  
  
  
  
  
}
}