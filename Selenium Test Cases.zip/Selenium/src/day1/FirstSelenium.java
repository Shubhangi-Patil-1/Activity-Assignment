package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstSelenium {
	public static void main(String[]args) {
	
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		driver.get("https://www.amazon.in");

		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
//		WebElement searchstore=driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));
		
		
//	System.out.println(driver.getTitle());
//	driver.quit();
	}

}



