package day1;


	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.firefox.FirefoxDriver;

	public class myprog {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.firefox.driver","C:\\Users\\HP\\Desktop\\Testing\\firefoxdriver_win32(1)\\firefoxdriver.exe");

	WebDriver driver=new FirefoxDriver();

	driver.get("http://www.amazon.in/");
	driver.manage().window().maximize();
	System.out.println(driver.getTitle());


	driver.findElement(By.id("twotabsearchtextbox")).sendKeys("jwellary");
	driver.findElement(By.id("nav-search-submit-button")).click();
	driver.findElement(By.linkText("EN")).click();
	driver.findElement(By.className("a-button-text")).click(); //cancel
	Thread.sleep(1000);
	driver.findElement(By.cssSelector("#nav-link-accountList ")).click(); //Sign-in

	//driver.navigate().back();
	//driver.navigate().forward();
	//driver.navigate().refresh();
	//Thread.sleep(51000);

	driver.navigate().to("http://www.edubridgeindia.com");
	//String Exception2 = driver.getTitle();
	System.out.println(driver.getTitle());
	driver.findElement(By.linkText("Log In")).click();

	driver.findElement(By.id("login_mobile")).sendKeys("8766401263");
	driver.findElement(By.id("login_password")).sendKeys("Omsai@2398");
	driver.findElement(By.id("btnLoginSubmit")).click();
	driver.findElement(By.id("twotabsearchtextbox")).sendKeys("");
	driver.findElement(By.id("nav-search-submit-button")).click();





	Thread.sleep(4000);

	//driver.quit();

	}

	}
