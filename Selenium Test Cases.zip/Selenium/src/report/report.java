package report;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


	public class report {
	public static void main(String[]args) {
	
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("http://127.0.0.1:5500/1stpage.html");
		
		
		
	driver.findElement(By.xpath("/html/body/div/div/div/button/a/h1")).click();
	
	driver.get("http://127.0.0.1:5500/2ndpage.html");
	  driver.findElement(By.xpath("/html/body/div/div/div/button/a/h1")).click();
//	  Thread.sleep(1000);

//	driver.manage().window().maximize();
//	System.out.println(driver.getTitle());
//	
	  driver.findElement(By.xpath("/html/body/form/div[1]/input[1]")).sendKeys("shubhangipatil2398@gnail.com");
	  driver.findElement(By.xpath("/html/body/form/div[1]/input[2]")).sendKeys("Omsai@2398");
//	  driver.findElement(By.xpath("/html/body/header/form[2]/input[3]")).click();
	  
	  driver.findElement(By.xpath("/html/body/form/div[1]/button")).click();//login
	  
	  driver.findElement(By.xpath(" /html/body/ul/div/button/a/h1\r\n")).click();//login quiz
	 
//	  Quize
	  
	  driver.findElement(By.xpath(" //*[@id=\"c\"]")).click();//radio button
	  
//	  Submit button
	  
	  
	driver.findElement(By.xpath("//*[@id=\"submit\"]")).click();  
	
	 driver.findElement(By.xpath("[@id=\"quiz\"]/button")).click();
	  driver.quit();
	  
	  
	
	 
	  
	
//		driver.navigate().back();
//		driver.navigate().forward();
//		driver.navigate().refresh();
////		WebElement searchstore=driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));
//		
		
//	System.out.println(driver.getTitle());
//	driver.quit();
	}

	}

