import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class promptalert {
 public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");

   WebDriver driver = new ChromeDriver();
   driver.get("https://demoqa.com/alerts");
   driver.manage().window().maximize();
   
   
   WebElement element = driver.findElement(By.id("promptbutton"));
   ((JavascriptExecutor) driver).executeScript("arguments[0].click()", element);
   Alert promptAlert  = driver.switchTo().alert();
   String alertText = promptAlert.getText();
   System.out.println("Alert text is " + alertText);
   promptAlert.sendKeys("Test User");
   
   
   
   promptAlert.accept();
  }
}


