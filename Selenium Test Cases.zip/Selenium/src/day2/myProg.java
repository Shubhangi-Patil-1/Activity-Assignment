package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class myProg {

public static void main(String[] args) throws InterruptedException
{
	System.setProperty("webdriver.chromefox.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");

WebDriver driver=new ChromeDriver();

driver.get("http://www.amazon.in/");
driver.manage().window().maximize();
System.out.println(driver.getTitle());


driver.findElement(By.id("twotabsearchtextbox")).sendKeys("women shoes");
//driver.findElement(By.id("nav-cart-count-container")).click();
driver.findElement(By.xpath("//*[@id=\"nav-hamburger-menu\"]")).click();

driver.findElement(By.xpath("//*[@id=\"hmenu-canvas-background\"]")).click();
Thread.sleep(1000);

driver.findElement(By.linkText("EN")).click();
Thread.sleep(1000);
driver.findElement(By.className("a-button-text")).click(); //cancel
Thread.sleep(1000);
driver.findElement(By.cssSelector("#nav-link-accountList ")).click(); //Sign-in
Thread.sleep(1000);
driver.findElement(By.id("ap_email")).sendKeys("shubhangipatil2398@gmail.com");
Thread.sleep(1000);
driver.findElement(By.id("continue")).click();
Thread.sleep(1000);
driver.findElement(By.cssSelector("#continue")).click();
Thread.sleep(1000);
driver.findElement(By.id("createAccountSubmit")).click();
Thread.sleep(1000);
driver.findElement(By.className("a-input-text")).sendKeys("shubhangi patil");
Thread.sleep(1000);
driver.findElement(By.id("ap_phone_number")).sendKeys("8766401263");
driver.findElement(By.name("secondaryLoginClaim")).sendKeys("shubhangipatil2398@gmail.com");
driver.findElement(By.name("password")).sendKeys("Omsai@2398");
driver.findElement(By.className("a-button-input")).click();
driver.quit();


//driver.navigate().back();
//driver.navigate().forward();
//driver.navigate().refresh();
//Thread.sleep(1000);

/*driver.navigate().to("http://www.edubridgeindia.com");
//String Exception2 = driver.getTitle();
System.out.println(driver.getTitle());
driver.findElement(By.linkText("Log In")).click();

driver.findElement(By.id("login_mobile")).sendKeys("9987115055");
driver.findElement(By.id("login_password")).sendKeys("P$poo986920");
driver.findElement(By.id("btnLoginSubmit")).click();
driver.findElement(By.id("twotabsearchtextbox")).sendKeys("");
driver.findElement(By.id("nav-search-submit-button")).click();

*/




//Thread.sleep(4000);

//driver.quit();

}

}
