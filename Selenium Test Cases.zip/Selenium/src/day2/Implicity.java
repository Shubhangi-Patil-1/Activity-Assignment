package day2;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Implicity {

	
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");


		
		WebDriver driver=new ChromeDriver();
		
//		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS );
		
		driver.get("https://www.amazon.in/");
		
		driver.findElement(By.xpath("//*[@id=\"nav-hamburger-menu\"]")).click();
	
		driver.findElement(By.xpath("//*[@id=\"hmenu-content\"]/ul[1]/li[18]/a/div")).click();
		
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS );
		
		driver.navigate().to("https://www.flipkart.com/");
		
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		
		driver.navigate().back();
		
		Thread.sleep(1000);
		
		driver.quit();		
	}

}