package day2;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Drag_Drop {

	public static void main(String[] args) throws InterruptedException {
		//Set the path of executable Browser Driver
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver(); //Parent p=new Child (webdriver is Parent & ChromeDriver is Child)
		driver.manage().window().maximize();
		driver.get("http://demo.guru99.com/test/drag_drop.html");					
        
		//Element which needs to drag. 
		//For Bank
        WebElement From=driver.findElement(By.xpath("//*[@id='credit2']/a"));	
         
         //Element on which need to drop.		
         WebElement To=driver.findElement(By.xpath("//*[@id='bank']/li"));					
         		
         //Using Action class for drag and drop.		
         Actions act=new Actions(driver);					

	//Dragged and dropped.		
         act.dragAndDrop(From, To).build().perform();
         Thread.sleep(1000);
        
         //for Amount
         WebElement From1=driver.findElement(By.xpath("/html/body/section/div/div/main/div/div/div/div/div/div/div[1]/div/ul/li[2]/a"));	
         
         //Element on which need to drop.		
         WebElement To1=driver.findElement(By.xpath("//*[@id=\"amt7\"]/li"));					
         		
         //Using Action class for drag and drop.		
         Actions act1=new Actions(driver);					

	//Dragged and dropped.		
         act1.dragAndDrop(From1, To1).build().perform();	
         Thread.sleep(1000);
         
         WebElement From11=driver.findElement(By.xpath("//*[@id=\"credit1\"]/a"));	
         
         //Element on which need to drop.		
         WebElement To11=driver.findElement(By.xpath("//*[@id=\"loan\"]/li"));					
         		
         //Using Action class for drag and drop.		
         Actions act11=new Actions(driver);					

	//Dragged and dropped.		
         act11.dragAndDrop(From11, To11).build().perform();
         Thread.sleep(1000);
         
        
         WebElement From111=driver.findElement(By.xpath("//*[@id=\"fourth\"]/a"));	
         
         //Element on which need to drop.		
         WebElement To111=driver.findElement(By.xpath("//*[@id=\"amt8\"]/li"));					
         		
         //Using Action class for drag and drop.		
         Actions act111=new Actions(driver);					

	//Dragged and dropped.		
         act111.dragAndDrop(From111, To111).build().perform();
       
         
	}		
}